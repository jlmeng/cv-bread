# bread > 2023-10-06 3:03pm
https://universe.roboflow.com/tutorial-xsyei/bread-rxi8k

Provided by a Roboflow user
License: Public Domain

